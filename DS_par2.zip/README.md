# DS_par2
Jonathan Quintana Matricula 201407121 jiquinta@espol.edu.ec
Guillermo Enrique Bernal Moreira 201411077 gebernal@espol.edu.ec
