
from control import login

print("Bienvenidos a restaurantes Espol \n")
bucle = True
usuario = []

while bucle:
    bucle = login.InicioDeSesion()


