from modelado import funcionesDeLectura

usuarios = {}
key = []
funcionesDeLectura.leerArchivo("dataAccess/usuarios.txt", usuarios, key)


