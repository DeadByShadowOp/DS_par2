from control import usuarios, funcionesComunes, restaurant
from modelado import usuarioClass, restauranteClass
tiposUsuarios = {1 :"usuario", 2: "administrador", 3: "adminRestaurante"}


def selectRol():
    print("1.- Administrador de restaurante")
    print("2.- Administrador de sistema")
    print("3.- Usuario regular")
    while True:
        op = int(input("Seleccione el tipo de usuario: "))
        if (op > 0) and (op < 4):
            break
            return tiposUsuarios.get(op)
        else:
            print("Opción erronea")

class userAdmin(usuarioClass.userLogin):
    def __init__(self,id,nombre,password,rol):
        usuarioClass.userLogin(id,nombre,password,rol)



    def addUser(self):
        key = len(usuarios.key)
        while True:
            id = input("Ingrese la CI del nuevo usuario: ")
            if id in usuarios.usuarios == False:
                break
            else:
                print("CI de usuario ya existe ingrese una diferente")
                funcionesComunes.pausa()

        name = input("ingrese el nombre del nuevo usuario: ")
        while True:
            contrasena = input("Ingrese la pass del nuevo usuario: ")
            conPass = input("Confirme su contraseña: ")
            if conPass == contrasena:
                print("Confirmacion de contraseña exitosa")
                break
            else:
                print("Error no coinciden datos")
                funcionesComunes.pausa()
        rol = selectRol()

        if rol == tiposUsuarios.get(3):
            #asistente,nombre,direccion,telefono,dueño,platillos
    nameR = input()

