class userLogin():
    id = ""
    nombre = ""
    password = ""
    rol = ""
    restaurante = ""